Please look into "index.html" for the main application page
